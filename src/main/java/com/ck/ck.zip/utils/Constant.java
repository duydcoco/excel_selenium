package com.ck.utils;
 
   public class Constant {
 
      public static final String URL = "https://commerce-ebama1r.edf.fr/ediarch/protected/root.zul";

      public static final String Username = "SCAAP1";

      public static final String Password = "Scaap1!";

      public static final String Facturation = "10008*";

//      public static final String Path_TestData = "C://Users//a00178//Desktop//";
      public static final String Path_TestData = "G:\\github_pro\\excel_read_write\\src\\main\\java\\com\\ck\\data\\";

      public static final String File_TestData = "Data.xlsx";

   }